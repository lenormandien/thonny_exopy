# thonny_exopy

Plugin Thonny NSI pour récupérer des exercices depuis une API avec aide IA.

## Installation

```bash
pip install thonny_exopy
